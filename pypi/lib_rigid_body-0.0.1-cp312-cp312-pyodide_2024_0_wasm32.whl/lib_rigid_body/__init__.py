try:
    from .lib_rigid_body import *
except Exception:
    try:
        from ._lib_rigid_body import *
    except Exception:
        raise ImportError("compiled extension not found; ensure CMake installs it into the package")
