try:
    # prefer compiled module name produced by bind.cc
    from .rigid_body_FEM import *
except Exception as e1:
    try:
        from ._lib_rigid_body import *
    except Exception as e2:
        raise ImportError(
            "compiled extension not found; ensure the extension was built and installed "
            "into the lib_rigid_body package. Inner errors: {}, {}".format(e1, e2)
        )
